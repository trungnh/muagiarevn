<?php


class WT_Account_Manager_Coupons {
	
	static $_post_id;

	static $_core_fields = array('post_title', 'post_content', 'post_excerpt');
	static $taxonomies = array('coupons_category', 'coupons_store_category');
	static $meta = array('_sh_sh_coupons_settings'=>array('expires_date', 'coupon_code'));
	static $post_data;
	
	function listing()
	{
		$user_id = get_current_user_id();

	    if( !$user_id ) return;

	    wt_account_manager_get_template_part('post_listing');
	}
	/**
	 * Handles form submission on save
	 *
	 * @param  CMB2  $cmb       The CMB2 object
	 * @param  array $post_data Array of post-data for new post
	 * @return mixed            New post ID if successful
	 */
	public static function post_form_submission( $cmb, $post_data = array() ) {
		//printr($cmb);
	    // If no form submission, bail
	    if ( empty( $_POST ) ) {
	        return false;
	    }
	    //printr($_POST);
	    // check required $_POST variables and security nonce
	    if (
	        ! isset( $_POST['submit-cmb'], $_POST['object_id'], $_POST[ $cmb->nonce() ] )
	        || ! wp_verify_nonce( $_POST[ $cmb->nonce() ], $cmb->nonce() )
	    ) {
	        return new WP_Error( 'security_fail', __( 'Security check failed.' ) );
	    }

	    if ( empty( $_POST['post_title'] ) ) {
	        return new WP_Error( 'post_data_missing', __( 'New post requires a title.' ) );
	    }

	    $user_id = get_current_user_id();

	    if( !$user_id ) return new WP_Error( 'post_data_missing', __( 'You must loggedin to submit a post.' ) );


	    //$cat_by_slug = get_term_by( 'slug', sh_set( $_POST, 'category' ), 'category');
	    
	    // Fetch sanitized values
	    $sanitized_values = $cmb->get_sanitized_values( $_POST );

	    // Set our post data arguments
	    $post_data['post_title']   = $sanitized_values['post_title'];
	    unset( $sanitized_values['post_title'] );
	    $post_data['post_content'] = $sanitized_values['post_content'];
	    unset( $sanitized_values['post_content'] );
	    
	    //if( !is_wp_error($cat_by_slug ) ) $post_data['tax_input']['category'] = sh_set( $cat_by_slug, 'term_id');
	    $post_data['tax_input']['coupons_category'] = explode(',', sh_set( $_POST, 'coupons_category' ) );
	    $post_data['tax_input']['coupons_store_category'] = sh_set( $_POST, 'coupons_store_category');
	    //printr($post_data);


	    if(esc_attr($_POST['object_id']) !== 'fake-id' && !empty($_POST['object_id']) ) $post_data['ID'] = $_POST['object_id'];
	    //printr($post_data);
	    // Create the new post
	    $new_submission_id = wp_insert_post( $post_data, true );

	    // If we hit a snag, update the user
	    if ( is_wp_error( $new_submission_id ) ) {
	        return $new_submission_id;
	    }


	    foreach (self::$meta as $key => $meta_array) {
	    	$meta_data = array();
	    	foreach ($meta_array as $meta_key) {
	    		if(isset($_POST[$meta_key])) $meta_data[$meta_key] = $_POST[$meta_key];
	    	}
	    	if( $meta_data ) update_post_meta($new_submission_id, $key, $meta_data);
	    }

	    /**
	     * Other than post_type and post_status, we want
	     * our uploaded attachment post to have the same post-data
	     */
	    unset( $post_data['post_type'] );
	    unset( $post_data['post_status'] );

	    // Try to upload the featured image
	    $img_id = sh_set( $_POST, 'submitted_post_thumbnail_id' );//wds_frontend_form_photo_upload( $new_submission_id, $post_data );
	    //media_handle_upload( $file_id, $post_id, $post_data, $overrides );
	    
	    // If our photo upload was successful, set the featured image
	    if ( $img_id && ! is_wp_error( $img_id ) ) {
	        set_post_thumbnail( $new_submission_id, $img_id );
	    }


	    // Loop through remaining (sanitized) data, and save to post-meta
	    /*foreach ( $sanitized_values as $key => $value ) {
	        update_post_meta( $new_submission_id, $key, $value );
	    }*/


	    return $new_submission_id;
	}


	public static function post_form_output()
	{
		wt_account_manager_get_template_part('coupon/coupon_form');
	}

	public static function edit_values($field_args, $field)
	{
		//print_r($field_args);exit;
		
		$post_id = isset($_GET['wtam_post_id']) ? $_GET['wtam_post_id'] : 'fake-id';
		$id = $field_args['id'];

		$value = '';

		if( $post_id !== self::$_post_id && $post_id !== 'fake-id' )
		{
			self::$_post_id = $post_id;
			$post = get_post(self::$_post_id);

			if( !is_wp_error($post) ) {
				self::$post_data = $post;
			}
	
		}

		if( in_array($id, self::$_core_fields ) && self::$post_data )
		{
			return isset( self::$post_data->$id ) ? self::$post_data->$id : '';
		}
		else if( in_array( $id, self::$taxonomies ) && $post_id !== 'fake-id' )
		{
			if( $id == 'coupons_category') return implode(',', (array)wp_get_post_terms( $post_id, $id, array('fields'=>'ids') ) );
			return wp_get_post_terms( $post_id, $id, array('fields'=>'slugs') );
		}
		else if( $post_id !== 'fake-id' )
		{
			$meta = get_post_meta($post_id, '_sh_sh_coupons_settings', true);
			if( $id == 'submitted_post_thumbnail' )
			{
				return wp_get_attachment_url(get_post_thumbnail_id($post_id));
			}
			else if( in_array($id, (array)self::$meta['_sh_sh_coupons_settings'] ) ) {

				return isset($meta[$id]) ? $meta[$id] : '';
			}
			return get_post_meta($post_id, $id, true);
		}

		return '';
	}
}