<?php 

include WT_AM_PATH.'thirdparty/cmb-field-type-sorter/cmb-field-sorter.php';
include WT_AM_PATH.'thirdparty/cmb-field-select2/cmb-field-select2.php';

$prefix = 'wt_account_manager_';

add_action('init', $prefix.'init');


function wt_account_manager_init()
{
	add_filter('wt_account_manager_config', function($conf){
		$conf[] = include WT_AM_PATH.'config/post.php';
		$conf[] = include WT_AM_PATH.'config/coupon.php';
		$conf[] = include WT_AM_PATH.'config/profile.php';
		//print_r($conf);exit;
		return $conf;
	});

	wt_account_manager_load_classes();
}


function wt_account_manager_load_classes()
{
	$prefix = 'wt_account_manager_';

	$files = scandir(WT_AM_PATH.'classes');
	$name = FALSE;
	foreach( $files as $file ) {
		if( $file == '.' || $file == '..' ) continue;

		// Is the request a class extension?  If so we load it too
		$path = WT_AM_PATH.'classes/'.$file;

		if( file_exists($path) )
		{
			$name = ucwords($prefix). str_replace('.php', '', $file)  ;

			if (class_exists($name) === FALSE)	require($path);
		}

		// Did we find the class?
		if ($name === FALSE) exit('Unable to locate the specified class in theme: '.$file);

		//if( $global ) $GLOBALS['_sh_base']->$class = new $name();
		new $name();	
	}
	
}


function wt_account_manager_get_template_part($template)
{
	$new_template = 'wt_account_manager/'.$template;
	$locate = locate_template( $new_template);

	if( $locate ) get_template_part($new_template);
	else include WT_AM_PATH.'templates/'.$template.'.php';
}

/**
 * Handle the cmb-frontend-form shortcode
 *
 * @param  array  $atts Array of shortcode attributes
 * @return string       Form html
 */
function comre_wow_themes_do_frontend_form_submission_shortcode( $atts = array() ) {

	ob_start();

	if(isset($_GET['wtam_current_page']) && esc_attr($_GET['wtam_current_page']) == 'post_form' )
	{
		do_action('wt_account_manager_post_form');	
	}
	else {
		wt_account_manager_get_template_part('post/post_listing');
	}
    //do_action('wt_account_manager_post_form');
    //
    return ob_get_clean();
}



add_shortcode( 'comre_frontend_post_submission', 'comre_wow_themes_do_frontend_form_submission_shortcode' );


/**
 * Handle the cmb-frontend-form shortcode
 *
 * @param  array  $atts Array of shortcode attributes
 * @return string       Form html
 */
function wtam_do_frontend_coupon_submission_shortcode( $atts = array() ) {

	ob_start();

	if(isset($_GET['wtam_current_page']) && esc_attr($_GET['wtam_current_page']) == 'coupon_form' )
	{
		do_action('wt_account_manager_coupons_form');	
	}
	else {
		wt_account_manager_get_template_part('coupon/coupon_listing');
	}
    //do_action('wt_account_manager_post_form');
    //
    return ob_get_clean();
}



add_shortcode( 'wtam_frontend_coupon_submission', 'wtam_do_frontend_coupon_submission_shortcode' );


/**
 * Handle the cmb-frontend-form shortcode
 *
 * @param  array  $atts Array of shortcode attributes
 * @return string       Form html
 */
function wtam_do_frontend_profile_submission_shortcode( $atts = array() ) {

	ob_start();

	do_action('wt_account_manager_users_form');	

    return ob_get_clean();
}



add_shortcode( 'wtam_frontend_profile_submission', 'wtam_do_frontend_profile_submission_shortcode' );


/**
 * Gets a number of terms and displays them as options
 * @param  string       $taxonomy Taxonomy terms to retrieve. Default is category.
 * @param  string|array $args     Optional. get_terms optional arguments
 * @return array                  An array of options that matches the CMB2 options array
 */
function wt_account_manager_cmb2_get_term_options( $taxonomy = 'category', $args = array() ) {

    $args['taxonomy'] = $taxonomy;
    // $defaults = array( 'taxonomy' => 'category' );
    $args = wp_parse_args( $args, array( 'taxonomy' => 'category' ) );

    $taxonomy = $args['taxonomy'];

    $terms = (array) get_terms( $taxonomy, $args );
    //if( $taxonomy == 'post_tag' ) printr($terms);
    // Initate an empty array
    $term_options = array();
    if ( ! empty( $terms ) ) {
        foreach ( $terms as $term ) {
            $term_options[ $term->term_id ] = $term->name;
        }
    }

    return $term_options;
}
