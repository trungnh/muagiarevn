<?php


class WT_Account_Manager_Profile {
	
	static $_post_id;

	static $_core_fields = array('user_login', 'display_name', 'user_email', 'user_pass');
	//static $taxonomies = array('coupons_category', 'coupons_store_category');
	static $meta = array( 'description', 'facebook', 'twitter', 'linkedin', 'pinterest', 'tumblr', 'google-plugin', 'profile_thumbnail_id', 'profile_thumbnail');
	static $post_data;
	
	function listing()
	{
		$user_id = get_current_user_id();

	    if( !$user_id ) return;

	    wt_account_manager_get_template_part('post_listing');
	}
	/**
	 * Handles form submission on save
	 *
	 * @param  CMB2  $cmb       The CMB2 object
	 * @param  array $post_data Array of post-data for new post
	 * @return mixed            New post ID if successful
	 */
	public static function post_form_submission( $cmb, $post_data = array() ) {
		//printr($cmb);
	    // If no form submission, bail
	    if ( empty( $_POST ) ) {
	        return false;
	    }
	    //printr($_POST);
	    // check required $_POST variables and security nonce
	    if (
	        ! isset( $_POST['submit-cmb'], $_POST['object_id'], $_POST[ $cmb->nonce() ] )
	        || ! wp_verify_nonce( $_POST[ $cmb->nonce() ], $cmb->nonce() )
	    ) {
	        return new WP_Error( 'security_fail', __( 'Security check failed.' ) );
	    }

	    if ( empty( $_POST['user_email'] ) ) {
	        return new WP_Error( 'post_data_missing', __( 'Email is required.' ) );
	    }

	    $user_id = get_current_user_id();

	    if( !$user_id ) return new WP_Error( 'post_data_missing', __( 'You must loggedin to submit a post.' ) );



	    //$cat_by_slug = get_term_by( 'slug', sh_set( $_POST, 'category' ), 'category');

	    // Set our post data arguments
	    $post_data['ID'] = $user_id;

	    foreach (self::$_core_fields as $value) {
	    	if(isset($_POST[$value])) $post_data[$value] = $_POST[$value];
	    }

	    //printr($post_data);
	    // Create the new post
	    $new_submission_id = wp_update_user( $post_data, true );

	    // If we hit a snag, update the user
	    if ( is_wp_error( $new_submission_id ) ) {
	        return $new_submission_id;
	    }


	    foreach (self::$meta as $meta_key) {
	    	if(isset($_POST[$meta_key]))	    	
	    		update_user_meta($new_submission_id, $meta_key, $_POST[$meta_key]);
	    }


	    return $new_submission_id;
	}


	public static function post_form_output()
	{
		wt_account_manager_get_template_part('profile/profile_form');
	}

	public static function edit_values($field_args, $field)
	{
		//print_r($field_args);exit;
		$user_id = get_current_user_id();
		$post_id = $user_id;
		$id = $field_args['id'];

		$value = '';

		if( $post_id !== self::$_post_id && $post_id !== 'fake-id' )
		{
			self::$_post_id = $post_id;
			$post = get_userdata(self::$_post_id);
			//printr($post);
			if( !is_wp_error($post) ) {
				self::$post_data = $post->data;
			}
	
		}

		if( in_array($id, self::$_core_fields ) && self::$post_data )
		{
			return isset( self::$post_data->$id ) ? self::$post_data->$id : '';
		}
		/*else if( in_array( $id, self::$taxonomies ) && $post_id !== 'fake-id' )
		{
			if( $id == 'coupons_category') return implode(',', (array)wp_get_post_terms( $post_id, $id, array('fields'=>'ids') ) );
			return wp_get_post_terms( $post_id, $id, array('fields'=>'slugs') );
		}*/
		else if( $post_id !== 'fake-id' )
		{
			//$meta = get_post_met($post_id, '_sh_sh_coupons_settings', true);
			if( $id == 'profile_thumbnail' )
			{
				//echo get_user_meta($user_id, 'profile_thumbnail', true);exit;
				return wp_get_attachment_url(get_user_meta($user_id, 'profile_thumbnail_id', true));
			}
			else if( in_array($id, (array)self::$meta ) ) {
				$meta = get_user_meta($post_id, $id, true);
				return isset($meta) ? $meta : '';
			}
			return get_post_meta($post_id, $id, true);
		}

		return '';
	}
}