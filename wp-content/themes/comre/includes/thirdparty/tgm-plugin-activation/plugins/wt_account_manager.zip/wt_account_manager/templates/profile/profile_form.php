<?php 
		
		$atts = array();
		// Current user
	    $user_id = get_current_user_id();

	    if( !$user_id ) return;

	    // Use ID of metabox in wds_frontend_form_register
	    $metabox_id = 'front-end-profile-form';

	    // since post ID will not exist yet, just need to pass it something
	    $object_id  = ( isset(  $_GET['wtam_post_id'] ) ) ? esc_attr($_GET['wtam_post_id']) : 'fake-id';

	    // Get CMB2 metabox object
	    $cmb = cmb2_get_metabox( $metabox_id, $object_id );

	    // Get $cmb object_types
	    $post_types = $cmb->prop( 'object_types' );

	    // Parse attributes. These shortcode attributes can be optionally overridden.
	    $atts = shortcode_atts( array(
	        'post_author' => $user_id ? $user_id : 1, // Current user, or admin
	        'post_status' => 'pending',
	        'post_type'   => reset( $post_types ), // Only use first object_type in array
	    ), $atts, 'cmb-frontend-form' );

	    // Initiate our output variable
	    $output = '';


	    // Handle form saving (if form has been submitted)
	    $new_id = WT_Account_Manager_Profile::post_form_submission($cmb);//comre_wow_themes_handle_frontend_new_post_form_submission( $cmb, $atts );

	    if ( $new_id ) {

	        if ( is_wp_error( $new_id ) ) {

	            // If there was an error with the submission, add it to our ouput.
	            $output .= '<h3>' . sprintf( __( 'There was an error in the submission: %s', 'comre' ), '<strong>'. $new_id->get_error_message() .'</strong>' ) . '</h3>';

	        } else {

	            // Get submitter's name
	            $name = isset( $_POST['submitted_author_name'] ) && $_POST['submitted_author_name']
	                ? ' '. $_POST['submitted_author_name']
	                : '';

	            // Add notice of submission
	            $output .= '<h3>' . sprintf( __( 'Thank you %s, your profile successfully updated', 'comre' ), esc_html( $name ) ) . '</h3>';
	        }

	    }

	    //echo '<a href="'.get_permalink().'" title="'.esc_html__('Back to Account').'">'.esc_html__('Back to Account').'</a>';

	    // Get our form
	    $output .= cmb2_get_metabox_form( $cmb, $object_id, array( 'save_button' => __( 'Update Profile', 'comre' ) ) );

	    echo $output;
