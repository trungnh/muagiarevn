<?php 

$return = array();

$return['submit_callback'] = array('WT_Account_Manager_Post', 'post_form_submission');
$return['action'] = 'post_form';
$return['output'] = array('WT_Account_Manager_Post', 'post_form_output');

$return['config'] = array(
        'id'           => 'front-end-post-form',
        'object_types' => array( 'post' ),
        'hookup'       => false,
        'save_fields'  => false,
        //'object_id'    => ( isset(  $_GET['wtam_post_id'] ) ) ? esc_attr($_GET['wtam_post_id']) : 'fake-id'
    );

$return['fields'][] = array(
        'name'    => __( 'New Post Title', 'comre' ),
        'id'      => 'post_title',
        'type'    => 'text',
        'default' => array('WT_Account_Manager_Post', 'edit_values'),
        'attributes'  => array(
	        'placeholder' => esc_html__('Enter post title', 'comre' ),
	        'class'        => 'form-control',
	        'required'    => 'required',
	    ),
    );

$return['fields'][] = array(
        'name'    => __( 'Post Content', 'comre' ),
        'id'      => 'post_content',
        'type'    => 'wysiwyg',
        'default' => array('WT_Account_Manager_Post', 'edit_values'),
        'options' => array(
            'textarea_rows' => 12,
            'media_buttons' => false,
        ),
    );

$return['fields'][] = array(
        'name'       => __( 'Featured Image', 'comre' ),
        'id'         => 'submitted_post_thumbnail',
        'type'       => 'file',
         'default' => array('WT_Account_Manager_Post', 'edit_values'),
	    'options' => array(
	        'url' => false, // Hide the text input for the url
	        'add_upload_file_text' => esc_html__('Featured image', 'comre' ) // Change upload button text. Default: "Add or Upload File"
	    ),
	    
    );

$return['fields'][] = array(
        'name' => __( 'Category', 'comre' ),
        'desc' => __( 'Please Choose Category.', 'comre' ),
        'id'   => 'category',
        'taxonomy' => 'category',
        'type' => 'pw_multiselect',
        'default' => array('WT_Account_Manager_Post', 'edit_values'),
        'options' => wt_account_manager_cmb2_get_term_options('category', array('hide_empty'=>0)),
        'attributes' => array(
        	//'class' => 'form-control',
        	//'multiple' => 'multiple'
        )
    );

$return['fields'][] = array(
        'name' => __( 'Tags', 'comre' ),
        'desc' => __( 'Choose Tags.', 'comre' ),
        'id'   => 'post_tag',
        'type' => 'taxonomy_multicheck',
        'taxonomy'	=> 'post_tag',
        'default' => array('WT_Account_Manager_Post', 'edit_values'),
        // Optional:
	    'options' => array(
	        'no_terms_text' => 'Sorry, no terms could be found.' // Change default text. Default: "No terms"
	    ),
	    
    );


return $return;