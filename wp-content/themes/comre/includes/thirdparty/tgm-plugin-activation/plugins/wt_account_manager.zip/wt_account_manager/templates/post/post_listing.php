<?php if( !defined('ABSPATH') ) exit('Unauthorized Access');

$user_id = get_current_user_id();

if( !$user_id ) return;

$permalink = get_permalink();
$query = new WP_Query(array('author'=> $user_id));

if( $query->have_posts() ):?>


<table class="table"> 
	<tr>
		<th>Title</th>
		<th>Category</th>
		<th>Tags</th>
		<th>Date</th>
		<th>Status</th>
	</tr>

	<?php while( $query->have_posts() ): $query->the_post(); ?>

		<tr>
			<td><a href="<?php echo esc_url(add_query_arg(array('wtam_current_page' => 'post_form', 'wtam_post_id'=>get_the_id()))); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></td>
			<td><?php the_category(); ?></td>
			<td><?php the_tags(); ?></td>
			<td><?php echo get_the_date(); ?></td>
			<td><?php echo get_post_status(get_the_id()); ?></td>
		</tr>
	<?php endwhile; ?>
</table>


<?php endif; 

wp_reset_postdata(); ?> 
