<?php 
/*
Plugin Name: WowThemes Account Manager
Plugin URI: http://themeforest.net/user/wow_themes
Description: Account manager for wow_themes Wordpress Themes
Version: 1.0
Author: Shahbaz Ahmed
Author URI: http://wow-themes.com
*/

// don't load directly
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

if( !class_exists('CMB2_Bootstrap_212') ) require_once 'CMB2/init.php';

if( !defined('WT_AM_PATH') ) define('WT_AM_PATH', plugin_dir_path( __FILE__ ) );
if( !defined('WT_AM_URL') ) define('WT_AM_URL', plugin_dir_url( __FILE__ ) );
include_once 'includes/loader.php';