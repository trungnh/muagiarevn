<?php


class WT_Account_Manager_Base {
	
	private $_config;
	private $cmb2;
	private $_prefix = 'wt_account_manager_';

	function __construct() {

		$this->_config = array();

		$this->_config = apply_filters($this->_prefix.'config', $this->_config);

		add_action( 'cmb2_init', array( $this, 'cmb2_init' ) );

	}


	function cmb2_init()
	{
		foreach( $this->_config as $conf )
		{
			$this->cmb2 = new_cmb2_box($conf['config']);
			$this->build_fields( $conf['fields'] );
			if( isset( $conf['action'] ) ) {
				add_action($this->_prefix.$conf['action'], $conf['output']);
			}
			/*if( isset( $conf['action'] ) ) {
				add_action($this->_prefix.$conf['action'], $conf['output']);
			}*/
			
		}
	}


	function build_fields($fields)
	{

		if(is_array($fields))
		{
			foreach( $fields as $field )
			{
				$this->cmb2->add_field($field);
			}
		}
	}

}