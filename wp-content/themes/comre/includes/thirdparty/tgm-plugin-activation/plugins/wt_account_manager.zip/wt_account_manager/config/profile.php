<?php 

$return = array();

$return['submit_callback'] = array('WT_Account_Manager_Profile', 'post_form_submission');
$return['action'] = 'users_form';
$return['output'] = array('WT_Account_Manager_Profile', 'post_form_output');

$return['config'] = array(
        'id'           => 'front-end-profile-form',
        'object_types' => array( 'users' ),
        'hookup'       => false,
        'save_fields'  => false,
        //'object_id'    => ( isset(  $_GET['wtam_post_id'] ) ) ? esc_attr($_GET['wtam_post_id']) : 'fake-id'
    );

$return['fields'][] = array(
        'name'    => __( 'Username', 'comre' ),
        'id'      => 'user_login',
        'type'    => 'text',
        'default' => array('WT_Account_Manager_Profile', 'edit_values'),
        'attributes'  => array(
	        //'placeholder' => esc_html__('Enter post title', 'comre' ),
	        'class'        => 'form-control',
	        'disabled'    => 'disabled',
	    ),
    );

$return['fields'][] = array(
        'name'    => __( 'Email', 'comre' ),
        'id'      => 'user_email',
        'type'    => 'text_email',
        'default' => array('WT_Account_Manager_Profile', 'edit_values'),
        'attributes'  => array(
            'placeholder' => esc_html__('Enter email address', 'comre' ),
            'class'        => 'form-control',
        ),  
    );

$return['fields'][] = array(
        'name'       => __( 'Profile Image', 'comre' ),
        'id'         => 'profile_thumbnail',
        'type'       => 'file',
         'default' => array('WT_Account_Manager_Profile', 'edit_values'),
	    'options' => array(
	        'url' => false, // Hide the text input for the url
	        'add_upload_file_text' => esc_html__('Profile image', 'comre' ) // Change upload button text. Default: "Add or Upload File"
	    ),
	    
    );

$return['fields'][] = array(
        'name'       => __( 'Display Name', 'comre' ),
        'id'         => 'display_name',
        'type'       => 'text',
        'default' => array('WT_Account_Manager_Profile', 'edit_values'),
        'attributes'  => array(
            'placeholder' => esc_html__('Enter display name', 'comre' ),
            'class'        => 'form-control',
        ),  
    );

$return['fields'][] = array(
        'name'       => __( 'Description / Bio', 'comre' ),
        'id'         => 'description',
        'type'       => 'textarea',
        'default' => array('WT_Account_Manager_Profile', 'edit_values'),
        'attributes'  => array(
            'placeholder' => esc_html__('Enter author biography or description', 'comre' ),
            'class'        => 'form-control',
        ),  
    );
$return['fields'][] = array(
        'name'       => __( 'New Password', 'comre' ),
        'id'         => 'user_pass',
        'type'       => 'text',
        'attributes'  => array(
            'placeholder' => esc_html__('Enter new password', 'comre' ),
            'class'        => 'form-control',
            'type'      => 'password',
        ),  
    );
$return['fields'][] = array(
        'name'       => __( 'Facebook', 'comre' ),
        'id'         => 'facebook',
        'type'       => 'text',
        'default' => array('WT_Account_Manager_Profile', 'edit_values'),
        'attributes'  => array(
            'placeholder' => 'http://',
            'class'        => 'form-control',
        ),  
    );
$return['fields'][] = array(
        'name'       => __( 'Twitter', 'comre' ),
        'id'         => 'twitter',
        'type'       => 'text',
        'default' => array('WT_Account_Manager_Profile', 'edit_values'),
        'attributes'  => array(
            'placeholder' => 'http://',
            'class'        => 'form-control',
        ),  
    );
$return['fields'][] = array(
        'name'       => __( 'Linkedin', 'comre' ),
        'id'         => 'linkedin',
        'type'       => 'text',
        'default' => array('WT_Account_Manager_Profile', 'edit_values'),
        'attributes'  => array(
            'placeholder' => 'http://',
            'class'        => 'form-control',
        ),
    );

$return['fields'][] = array(
        'name'       => __( 'Pinterest', 'comre' ),
        'id'         => 'pinterest',
        'type'       => 'text',
        'default' => array('WT_Account_Manager_Profile', 'edit_values'),
        'attributes'  => array(
            'placeholder' => 'http://',
            'class'        => 'form-control',
        ),
    );
$return['fields'][] = array(
        'name'       => __( 'Tumblr', 'comre' ),
        'id'         => 'tumblr',
        'type'       => 'text',
        'default' => array('WT_Account_Manager_Profile', 'edit_values'),
        'attributes'  => array(
            'placeholder' => 'http://',
            'class'        => 'form-control',
        ),
    );
$return['fields'][] = array(
        'name'       => __( 'Google+', 'comre' ),
        'id'         => 'google-plus',
        'type'       => 'text',
        'default' => array('WT_Account_Manager_Profile', 'edit_values'),
        'attributes'  => array(
            'placeholder' => 'http://',
            'class'        => 'form-control',
        ),
    );



return $return;